#!/usr/bin/php -q
<?php
  set_time_limit(30);
  require('phpagi.php');
  require('class.RestRequest.php');
  error_reporting(E_ALL);

//  $agi = new AGI();
//  $agi->answer();
//$agi->exec('Dial', "SIP/1000,10,F(voicebox,22222,1");
/*$agi->exec('Dial', "SIP/1000,10"); 
$statusabc=$agi->get_variable(DIALSTATUS);
$agi->exec('Dial', "SIP/"$statusabc[data]",10");*/
//$agi->exec('Dial', "SIP/"$status",10");
/* $cid = $agi->parse_callerid();
  $agi->text2wav("Hello, {$cid['name']}.");
  do
  {
    $agi->text2wav('Enter some numbers and then press the pound key. Press 1 1 1 followed by the pound key to quit.');
    $result = $agi->get_data('beep', 3000, 20);
    $keys = $result['result'];
    $agi->text2wav("You entered $keys");
  } while($keys != '111');
  $agi->text2wav('Goodbye');
  $agi->hangup();
*/
//	$dialNumber = "1000";
	$agi_object = new AGI();
	$request = new RestClient();
///////////////////////////////////

$data_string = '{"num":["'.$dialNumber.'"]}';


////                $ch = curl_init('http://ardsmonitoring.app.veery.cloud/DVP/API/1.0.0.0/ARDS/MONITORING/resources');
//		$ch = curl_init('http://192.168.37.137/sample_restapi/marketplace/test');
//                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "GET");
//		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
//                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
//                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
//                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
//                                'Content-Type: application/json',
//                                'Content-Length: ' . strlen($data_string)));
/*,
                                'companyinfo: 1:103',
                                'Authorization: bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzI1NiJ9.eyJpc3MiOiJzdWtpdGhhIiwianRpIjoiYWEzOGRmZWYtNDFhOC00MWUyLTgwMzktOTJjZTY0YjM4ZDFmIiwic3ViIjoiNTZhOWU3NTlmYjA3MTkwN2EwMDAwMDAxMjVkOWU4MGI1YzdjNGY5ODQ2NmY5MjExNzk2ZWJmNDMiLCJleHAiOjE5MDIzODExMTgsInRlbmFudCI6LTEsImNvbXBhbnkiOi0xLCJzY29wZSI6W3sicmVzb3VyY2UiOiJhbGwiLCJhY3Rpb25zIjoiYWxsIn1dLCJpYXQiOjE0NzAzODExMTh9.Gmlu00Uj66Fzts-w6qEwNUz46XYGzE8wHUhAJOFtiRo')
                                );
*/
//                $result = curl_exec($ch);
		$result = $request->getResult("GET","http://192.168.37.137/sample_restapi/marketplace/test",$data_string);
                $calldata = json_decode($result,true);
$dialNumber = $calldata["num"];

//////////////////////////////////


	$agi_object->exec('Dial', "SIP/$dialNumber,10");		
	$i=0;
	while($i<1){
	$statusabc=$agi_object->get_variable(DIALSTATUS);
	//log_agi("Dial Status abc start noanswer****** $statusabc[data]");

	if(empty($statusabc[data])){
	//	log_agi("Start Dial Status abc ****** empty");
		$i=0;
		//continue script until set dialstatus
		}
	else
	{
	//	log_agi("Dial Status abc noanswer****** $statusabc[data]");
		$i++;
		}
	}
	
	if(($statusabc[data] =="NOANSWER")){
	//	log_agi("end Dial Status $status[data]");
		
		$agi_object->exec("Voicemail","1234");

		}

?>
