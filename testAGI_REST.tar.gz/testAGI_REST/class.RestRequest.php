<?php

/**
 * @author achintha
 * @copyright 2017
 */


class RestClient
{
	function getResult($method,$url,$data_String)
	{

//                $ch = curl_init('http://ardsmonitoring.app.veery.cloud/DVP/API/1.0.0.0/ARDS/MONITORING/resources');
//                $ch = curl_init('http://192.168.37.137/sample_restapi/marketplace/test');
                $ch = curl_init($url);
                curl_setopt($ch, CURLOPT_CUSTOMREQUEST, $method);
//              curl_setopt($ch, CURLOPT_CUSTOMREQUEST, "POST");
                curl_setopt($ch, CURLOPT_POSTFIELDS, $data_string);
                curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
                curl_setopt($ch, CURLOPT_HTTPHEADER, array(
                                'Content-Type: application/json',
                                'Content-Length: ' . strlen($data_string)));
                $result = curl_exec($ch);
		return $result;

	}	

}

?>
