

<?php

	define("ROOT_PATH", "/var/www/html");
	define("BASE_PATH", "/var/www/htm/marketplace");

	
//	define("SVC_OS_URL", "http://developer.duoworld.com:3000");
//	define("SVC_AUTH_URL", "http://developer.duoworld.com:3048");
	
?>
